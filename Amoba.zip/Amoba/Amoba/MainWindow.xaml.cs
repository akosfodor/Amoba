﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Amoba
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Gameover();
        }

        bool X = true;
        bool GameOver = false;
        List<string> Xmezok = new List<string>();
        List<string> Kormezok = new List<string>();

        public void Turn()
        {

                if (GameOver)
                    return;

                if(X)
                {
                    player.Content = "'O' játékos";
                }
                
                else
                {
                    player.Content = "'X' játékos";
                }

                X =! X;
                
        } 

        public void Button_Click(object sender, RoutedEventArgs e)
        {
            if (GameOver)
                return; 

            Button button = (Button)sender;
            string buttonName = button.Name;

            if (X)
            {
                button.Content = "X";
                Xmezok.Add(buttonName);
                button.IsEnabled = false;
            }
            else
            {
                button.Content = "O";
                Kormezok.Add(buttonName);
                button.IsEnabled = false;
            }

            Gameover(); 

            Turn(); 
        }

        public void Gameover()
        {
            List<List<string>> gyozelmek = new List<List<string>>
    {
            new List<string> { "bf", "kk", "ja" },
            new List<string> { "jf", "kk", "ba" },
            new List<string> { "bf", "kf", "jf" },
            new List<string> { "bk", "kk", "jk" },
            new List<string> { "ba", "ka", "ja" },
            new List<string> { "bf", "bk", "ba" },
            new List<string> { "kf", "kk", "ka" },
            new List<string> { "jf", "jk", "ja" }
    };

            foreach (var komb in gyozelmek)
            {
                if (komb.All(move => Xmezok.Contains(move)))
                {
                    result.Content = "'X' játékos nyert.";
                    GameOver = true;
                    return;
                }
                else if (komb.All(move => Kormezok.Contains(move)))
                {
                    result.Content = "'O' játékos nyert.";
                    GameOver = true;
                    return;
                }
            }

            if (Xmezok.Count + Kormezok.Count == 9)
            {
                result.Content = "Döntetlen!";
                GameOver = true;
            }
        }
    }
}
